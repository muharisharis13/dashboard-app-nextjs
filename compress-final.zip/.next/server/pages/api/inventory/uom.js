"use strict";
(() => {
var exports = {};
exports.id = 55;
exports.ids = [55];
exports.modules = {

/***/ 2396:
/***/ ((module) => {

module.exports = require("http-status");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 7004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ excuteQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);
// db.js

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: "localhost",
        port: 3306,
        database: "db_toko_haris",
        user: "root",
        password: ""
    }
});
async function excuteQuery({ query  }) {
    try {
        const results = await db.query(query);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 7549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7004);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2396);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status__WEBPACK_IMPORTED_MODULE_1__);


async function handler(req, res) {
    const method = req.method;
    if (method === "POST") {
        const { uom_name  } = req.body;
        try {
            const data = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `
        insert into
        uom
        (uom_name)
        values
        ('${uom_name}')
        `
            });
            res.status(200).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                code: 200,
                data: data
            });
        } catch (error) {
            res.status(500).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                code: 500,
                data: error
            });
        }
    } else {
        const { page =1 , uom_name: uom_name1 , limit  } = req.query;
        const per_page = 10;
        const start = page > 1 ? page * per_page - per_page : 0;
        const totalRow = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: `select count(*) as totalRow  from uom  ${uom_name1 ? `where uom_name LIKE '%${uom_name1}%' ` : ""}`
        });
        const last_page = Math.ceil(totalRow[0]?.totalRow / per_page);
        try {
            const data1 = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `
          select * from uom
          ${uom_name1 ? `where uom_name LIKE '%${uom_name1}%' ` : ""}
          ${limit === "*" ? "" : `LIMIT ${start} , ${per_page}`}
        `
            });
            if (limit === "*") {
                res.status(200).json({
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                    code: 200,
                    data: data1
                });
            } else {
                res.status(200).json({
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                    code: 200,
                    data: data1,
                    page: parseInt(page),
                    last_page: last_page,
                    per_page: per_page,
                    total: totalRow[0]?.totalRow
                });
            }
        } catch (error1) {
            res.status(500).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                code: 500,
                data: error1
            });
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7549));
module.exports = __webpack_exports__;

})();