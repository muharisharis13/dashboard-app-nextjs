"use strict";
(() => {
var exports = {};
exports.id = 881;
exports.ids = [881];
exports.modules = {

/***/ 2396:
/***/ ((module) => {

module.exports = require("http-status");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 7004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ excuteQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);
// db.js

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: "localhost",
        port: 3306,
        database: "db_toko_haris",
        user: "root",
        password: ""
    }
});
async function excuteQuery({ query  }) {
    try {
        const results = await db.query(query);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 1998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7004);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2396);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status__WEBPACK_IMPORTED_MODULE_1__);


async function handler(req, res) {
    const { id_product  } = req.query;
    const method = req.method;
    if (method === "PUT") {
        const { product_name , capital_price , price , min_stock , uom_id , category_id , type_price  } = req.body;
        try {
            const data = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `
         update product
         set product_name='${product_name}', capital_price=${capital_price}, price=${price},  min_stock=${min_stock}, uom_id=${uom_id}, category_id=${category_id}, type_price='${type_price}', updatedAt=CURRENT_TIMESTAMP
         where id=${id_product}
        `
            });
            if (data?.protocol41 === true) {
                res.status(200).json({
                    code: 200,
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                    data: "Success for edited"
                });
            } else {
                res.status(400).json({
                    code: 400,
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[400]),
                    data: "Something Wrong with input"
                });
            }
        } catch (error) {
            res.status(500).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                code: 500,
                data: error
            });
        }
    } else if (method === "DELETE") {
        const data1 = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: `
        delete from product
        where id=${id_product}
      `
        });
        if (data1?.protocol41 === true) {
            res.status(200).json({
                code: 200,
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                data: "Success for deleted"
            });
        } else {
            res.status(400).json({
                code: 400,
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[400]),
                data: "Something Wrong with method"
            });
        }
    } else {
        try {
            const data2 = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `
        select product.*,uom.uom_name,category.category_name
        from product
        left join uom 
        on product.uom_id = uom.id
        left join category 
        on product.category_id = category.id
        where product.id = ${id_product}
        `
            });
            res.status(200).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                code: 200,
                data: data2[0]
            });
        } catch (error1) {
            res.status(500).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                code: 500,
                data: error1
            });
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1998));
module.exports = __webpack_exports__;

})();