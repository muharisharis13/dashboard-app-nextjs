"use strict";
(() => {
var exports = {};
exports.id = 732;
exports.ids = [732];
exports.modules = {

/***/ 2396:
/***/ ((module) => {

module.exports = require("http-status");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 7004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ excuteQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);
// db.js

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: "localhost",
        port: 3306,
        database: "db_toko_haris",
        user: "root",
        password: ""
    }
});
async function excuteQuery({ query  }) {
    try {
        const results = await db.query(query);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 241:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7004);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2396);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status__WEBPACK_IMPORTED_MODULE_1__);


const handler = async (req, res)=>{
    const method = req.method;
    const { selling_id  } = req.query;
    if (method === "GET") {
        try {
            await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `
          select selling_detail.*, product.product_name 
          from selling_detail
          left join product
          on selling_detail.product_id = product.id
          where selling_id=${selling_id}
        `
            }).then((result)=>{
                res.status(200).json({
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                    code: 200,
                    data: result
                });
            });
        } catch (error) {
            res.status(500).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                code: 500,
                message: error
            });
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(241));
module.exports = __webpack_exports__;

})();