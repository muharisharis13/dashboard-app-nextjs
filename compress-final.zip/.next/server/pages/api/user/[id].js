"use strict";
(() => {
var exports = {};
exports.id = 438;
exports.ids = [438];
exports.modules = {

/***/ 2396:
/***/ ((module) => {

module.exports = require("http-status");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 8602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7004);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2396);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(165);



async function handler(req, res) {
    const { id  } = req.query;
    const method = req.method;
    const { firstname , lastname  } = req.body;
    if (method === "PUT") {
        try {
            const data = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `update user set firstname='${firstname}',lastname='${lastname}' where id=${id}`
            });
            if (data) {
                res.status(200).json({
                    code: 200,
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                    data
                });
            } else {
                res.status(400).json({
                    code: 400,
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[400]),
                    data: "User not found !"
                });
            }
        } catch (error) {
            res.status(500).json({
                code: 500,
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                data: error
            });
        }
    } else {
        try {
            const data1 = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: "select * from user where id=" + id
            });
            res.status(200).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                code: 200,
                data: data1[0]
            });
        } catch (error1) {
            res.status(500).json({
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                code: 500,
                data: error1
            });
        }
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [719], () => (__webpack_exec__(8602)));
module.exports = __webpack_exports__;

})();