"use strict";
(() => {
var exports = {};
exports.id = 123;
exports.ids = [123];
exports.modules = {

/***/ 2396:
/***/ ((module) => {

module.exports = require("http-status");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 9762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7004);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2396);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(165);



const { verifyRefreshToken , createToken , createRefreshToken  } = _utils_server__WEBPACK_IMPORTED_MODULE_2__/* .token */ .r;
async function handler(req, res) {
    const { method , body  } = req;
    // const { refreshToken, username } = body
    const { refreshToken , username  } = JSON.parse(body);
    // console.log({ body: JSON.parse(body) })
    if (method === "POST") {
        try {
            const isValid = verifyRefreshToken(username, refreshToken);
            if (!isValid) {
                return res.status(401).json({
                    code: 401,
                    message: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[401]),
                    data: "Invalid token,try login again"
                });
            }
            const token = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `select * from token where refresh_token='${refreshToken}'`
            });
            if (token.length > 0) {
                const getUser = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                    query: `select id,firstname,lastname,createdAt,updatedAt,role_id,username from user where username='${username}'and id='${token[0].id_user}'`
                });
                if (getUser.length > 0) {
                    const dataToken = getUser[0];
                    const newToken = createToken({
                        ...dataToken
                    });
                    const newRefreshToken = createRefreshToken({
                        ...dataToken
                    });
                    const updateToken = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                        query: `update token set token='${newToken}',refresh_token='${newRefreshToken}', updatedAt=CURRENT_TIMESTAMP where id_user=${token[0].id_user}`
                    });
                    res.status(200).json({
                        code: 200,
                        status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                        data: {
                            type: "Bearer",
                            token: newToken,
                            refreshToken: newRefreshToken,
                            updateToken
                        }
                    });
                }
            }
        } catch (error) {
            res.status(500).json({
                code: 500,
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                data: error
            });
        }
    } else {
        res.status(400).json({
            code: 400,
            status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[400]),
            data: "Invalid Method !"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [719], () => (__webpack_exec__(9762)));
module.exports = __webpack_exports__;

})();