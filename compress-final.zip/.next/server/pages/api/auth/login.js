"use strict";
(() => {
var exports = {};
exports.id = 908;
exports.ids = [908];
exports.modules = {

/***/ 2396:
/***/ ((module) => {

module.exports = require("http-status");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7004);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2396);
/* harmony import */ var http_status__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_status__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(165);



const { hashPassword  } = _utils_server__WEBPACK_IMPORTED_MODULE_2__/* .crypto */ .eL;
const getTokenById = async (id)=>{
    if (id) {
        return await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: `select * from token where id_user=${id}`
        });
    } else {
        return "Id is Required";
    }
};
async function handler(req, res) {
    const { method , body  } = req;
    const { username , password  } = body;
    if (method === "POST") {
        try {
            const data = await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                query: `select id,username,firstname,lastname,createdAt,updatedAt,role_id from user where username='${username}' and password='${hashPassword(password)}'`
            });
            if (data.length > 0) {
                console.log("sebelum");
                const dataToken = data[0];
                const tokenData = _utils_server__WEBPACK_IMPORTED_MODULE_2__/* .token.createToken */ .r.createToken({
                    ...dataToken
                });
                const refresh_token = _utils_server__WEBPACK_IMPORTED_MODULE_2__/* .token.createRefreshToken */ .r.createRefreshToken({
                    ...dataToken
                });
                getTokenById(data[0].id).then(async (resToken)=>{
                    if (resToken && resToken.length > 0) {
                        await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                            query: `update token set token='${tokenData}', refresh_token='${refresh_token}', updatedAt=CURRENT_TIMESTAMP where id_user=${data[0].id}`
                        });
                    } else {
                        await (0,_database__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
                            query: `insert into token (token,refresh_token,id_user) values ('${tokenData}','${refresh_token}',${data[0].id})`
                        });
                    }
                });
                res.status(200).json({
                    code: 200,
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[200]),
                    data: {
                        ...data[0],
                        access: {
                            type: "Bearer",
                            token: tokenData,
                            refreshToken: refresh_token
                        }
                    }
                });
            } else {
                res.status(401).json({
                    code: 401,
                    status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[401]),
                    data: "username or password wrong !"
                });
            }
        } catch (error) {
            res.status(500).json({
                code: 500,
                status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[500]),
                data: error
            });
        }
    } else {
        res.status(400).json({
            code: 400,
            status: (http_status__WEBPACK_IMPORTED_MODULE_1___default()[400]),
            data: "Invalid Method !"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [719], () => (__webpack_exec__(6205)));
module.exports = __webpack_exports__;

})();