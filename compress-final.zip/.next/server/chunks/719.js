"use strict";
exports.id = 719;
exports.ids = [719];
exports.modules = {

/***/ 7004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ excuteQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);
// db.js

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: "localhost",
        port: 3306,
        database: "db_toko_haris",
        user: "root",
        password: ""
    }
});
async function excuteQuery({ query  }) {
    try {
        const results = await db.query(query);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 165:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "eL": () => (/* reexport */ crypto_namespaceObject),
  "r": () => (/* reexport */ token_namespaceObject)
});

// UNUSED EXPORTS: responseJson

// NAMESPACE OBJECT: ./utils/server/crypto.js
var crypto_namespaceObject = {};
__webpack_require__.r(crypto_namespaceObject);
__webpack_require__.d(crypto_namespaceObject, {
  "hashPassword": () => (hashPassword)
});

// NAMESPACE OBJECT: ./utils/server/token.js
var token_namespaceObject = {};
__webpack_require__.r(token_namespaceObject);
__webpack_require__.d(token_namespaceObject, {
  "createRefreshToken": () => (createRefreshToken),
  "createToken": () => (createToken),
  "verifyRefreshToken": () => (verifyRefreshToken)
});

// EXTERNAL MODULE: external "http-status"
var external_http_status_ = __webpack_require__(2396);
;// CONCATENATED MODULE: ./utils/server/responseJson.js

function responseJson({ res , code , data  }) {
    return res.json({
        status: httpStatus[code],
        code,
        data
    });
}

// EXTERNAL MODULE: external "crypto"
var external_crypto_ = __webpack_require__(6113);
var external_crypto_default = /*#__PURE__*/__webpack_require__.n(external_crypto_);
;// CONCATENATED MODULE: ./utils/server/crypto.js

const hashPassword = (data)=>{
    return external_crypto_default().createHash("md5").update(data).digest("hex");
};


// EXTERNAL MODULE: external "jsonwebtoken"
var external_jsonwebtoken_ = __webpack_require__(9344);
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_);
;// CONCATENATED MODULE: ./utils/server/token.js

const tokenLife = "1s";
const createToken = (data)=>external_jsonwebtoken_default().sign(data, "admin_22", {
        expiresIn: tokenLife
    });
const createRefreshToken = (data)=>external_jsonwebtoken_default().sign(data, "admin_ref_22");
const verifyRefreshToken = (username, token)=>{
    try {
        const decoded = external_jsonwebtoken_default().verify(token, "admin_ref_22");
        return decoded.username === username;
    } catch (error) {
        return false;
    }
};


;// CONCATENATED MODULE: ./utils/server/index.js






/***/ })

};
;