"use strict";
exports.id = 558;
exports.ids = [558];
exports.modules = {

/***/ 2940:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1837);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, _cookie__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, _cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const baseURL = `${"http://localhost:3000/"}api`;
const timeout = 16000;
const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL,
    timeout,
    headers: {
        "Content-Type": "application/json"
    }
});
instance.interceptors.request.use(async (config)=>{
    let token = _cookie__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("token");
    config.headers["Authorization"] = `Bearer ${token}`;
    return config;
});
const refreshToken = async ()=>{
    const refreshToken = _cookie__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("refreshToken");
    const username = _cookie__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("username");
    console.log("ini refresh");
    return instance.post("/auth/refreshToken", {
        refreshToken,
        username
    });
};
instance.setToken = (token)=>{
    instance.defaults.headers["Authorization"] = `Bearer ${token}`;
    _cookie__WEBPACK_IMPORTED_MODULE_1__/* ["default"].set */ .Z.set({
        label: "token",
        value: token
    });
};
let isRefreshing = false;
let requests = [];
instance.interceptors.response.use(undefined, async (err)=>{
    const error = err.response;
    if (error && error.code === 401) {
        const config = error.config;
        if (!isRefreshing) {
            isRefreshing = true;
            return refreshToken().then((res)=>{
                const { token , refreshToken  } = res.data.data;
                _cookie__WEBPACK_IMPORTED_MODULE_1__/* ["default"].set */ .Z.set({
                    label: "refreshToken",
                    value: refreshToken
                });
                instance.setToken(token);
                requests.forEach((cb)=>cb(token));
                requests = [];
                return instance(config);
            }).catch(async (res)=>{
                console.error("RefreshToken Error =>", res);
                let token = _cookie__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get("token");
                requests.forEach((cb)=>cb(token));
            }).finally(()=>{
                isRefreshing = false;
            });
        } else {
            return new Promise((resolve)=>{
                requests.push((token)=>{
                    config.baseURL = baseURL;
                    config.headers["Authorization"] = `Bearer ${token}`;
                    resolve(instance(config));
                });
            });
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (instance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1837:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class cookie {
    set({ label , value  }) {
        return js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set(label, value);
    }
    get(label) {
        return js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(label);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new cookie());

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DateFormat": () => (/* binding */ DateFormat),
/* harmony export */   "MoneyFormat": () => (/* binding */ MoneyFormat)
/* harmony export */ });
function MoneyFormat(number) {
    try {
        number = parseFloat(number);
        //return number != null ? number.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') : null;
        // // debugger;
        return number != undefined ? isNaN(number) ? "0" : number.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,") : "0";
    } catch (e) {
        // // debugger
        return "0";
    }
}
function DateFormat(p_date) {
    if (p_date) {
        let new_date = new Date(p_date);
        let dd = new_date.getDate();
        let mm = new_date.toLocaleString("default", {
            month: "short"
        }); //January is 0!
        let yyyy = new_date.getFullYear();
        if (dd < 10) {
            dd = "0" + dd;
        }
        if (mm < 10) {
            mm = "0" + mm;
        }
        var date_result = dd + "-" + mm + "-" + yyyy;
        if (date_result == "01-01-1900") {
            return "";
        } else {
            return dd + "-" + mm + "-" + yyyy;
        }
    } else {
        return null;
    }
}


/***/ }),

/***/ 558:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vj": () => (/* reexport safe */ _cookie__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "YD": () => (/* reexport safe */ _axios__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "uM": () => (/* reexport safe */ _queryString__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "zW": () => (/* reexport module object */ _formatter__WEBPACK_IMPORTED_MODULE_3__)
/* harmony export */ });
/* harmony import */ var _axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2940);
/* harmony import */ var _cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1837);
/* harmony import */ var _queryString__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2960);
/* harmony import */ var _formatter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2544);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axios__WEBPACK_IMPORTED_MODULE_0__, _cookie__WEBPACK_IMPORTED_MODULE_1__, _queryString__WEBPACK_IMPORTED_MODULE_2__]);
([_axios__WEBPACK_IMPORTED_MODULE_0__, _cookie__WEBPACK_IMPORTED_MODULE_1__, _queryString__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2960:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var query_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([query_string__WEBPACK_IMPORTED_MODULE_0__]);
query_string__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const QueryStringFunction = (object)=>{
    let ResultObjectKeys = Object.keys(object);
    ResultObjectKeys.map((item)=>{
        if (object[item] === "" || object[item] === null || object[item] === undefined) {
            delete object[item];
        }
    });
    return query_string__WEBPACK_IMPORTED_MODULE_0__["default"].stringify(object);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QueryStringFunction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;