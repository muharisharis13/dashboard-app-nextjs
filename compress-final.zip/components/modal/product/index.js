import ModalEdit from "./edit";
import ModalAdd from "./add";

export { ModalAdd, ModalEdit };
