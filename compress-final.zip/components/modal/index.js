import ModalCategory from "./category";

export { ModalCategory };
