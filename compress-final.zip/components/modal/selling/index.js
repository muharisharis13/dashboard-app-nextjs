import ModalDetailSelling from "./detail";

export default function Modal() {
  return {
    ModalDetailSelling,
  };
}
