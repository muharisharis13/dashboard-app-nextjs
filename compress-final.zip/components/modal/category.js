import Modal from "../modals";

const ModalCategory = () => {
  <Modal title="Add Category" idModal="ModallAddCategory">
    Modal add category
  </Modal>;
};

export default ModalCategory;
