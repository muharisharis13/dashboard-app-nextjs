import ModalCreate from "./create";

export default function Modal() {
  return {
    ModalCreate,
  };
}
