import PurchasingCollapse from "./collapse";

export default function components() {
  return { PurchasingCollapse };
}
