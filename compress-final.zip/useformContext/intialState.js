const intialState = {
  loading: false,
  search: "",
  selected: {
    category: "",
    uom: "",
    type_price: "",
    product: "",
  },
  toast: {
    title: "Success",
    content: "content",
    show: false,
    type: "primary",
  },
};

export default intialState;
